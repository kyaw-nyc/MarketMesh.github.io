import requests

url = "https://trading-api.kalshi.com/trade-api/v2/login"

payload = {
    "email": "vladimir21beloglazov@gmail.com",
    "password": "kocfyd-qokjAz-8fupda"
}
headers = {
    "accept": "application/json",
    "content-type": "application/json"
}

response = requests.post(url, json=payload, headers=headers)

password = response.text

url = "https://api.elections.kalshi.com/trade-api/v2/markets"

headers = {
    "accept": "application/json",
    "Authorization": password
}

response = requests.get(url, headers=headers)

print(response.text)